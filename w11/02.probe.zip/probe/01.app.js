$( document).ready( function() { 
	var $body = $( 'body').css({ 'font-size': $.io.defs.fonts.large})
	var L = [];
	var wait = function() { $body.empty().append( $.ltt( L, '<br/>')); }
	var one = function() { 
		var before = $.iotime();
		$.get( 'http://cloudq9test.herokuapp.com', { rand: $.mathRandom( 10)}, function( text) { 
			after = $.iotime(); var v = text.length + ',' + ( after - before);
			L.push( v); //console.log( 'I am here', v);
			wait();
		}, 'text');
		
	}
	for ( var i = 0; i < 2; i++) one(); // parallel, but callbacks are sequential
})

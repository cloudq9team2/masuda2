// web.js
//var $, window;
//var jsdom = require( 'jsdom');
var fs = require( 'fs');
var express = require( 'express');
var logfmt = require( 'logfmt');
var app = express();
app.use( logfmt.requestLogger());
app.get( '/', function( req, rep) { 	// name, aff, email
	// if empty query, go to the status HTML
	if ( ! req.query || ! req.query.rand) return fs.readFile( './index.html', 'utf8', function( err, text) { rep.send( text); })
	if ( req.query && req.query.script) return rep.send( '<script>console.log( "I am here"); if ( callback) callback( "test"); </script>');
	// generate a random message
	var msg = '';
	for ( var i = 0; i < 1000; i++) {
		for ( var y = 0; y < 100; y++) msg += '.';
		msg += "\n";
	}
	rep.send( msg);
})
var port = Number( process.env.PORT || 5000);
app.listen( port, function() { console.log( 'Listening on ' + port); })
